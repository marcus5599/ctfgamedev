using UnityEngine;
using UnityEngine.SceneManagement;


// Scene After Sign In and the Competition Has not started Yet 
namespace Objects
{
	public class Scene2: MonoBehaviour {
	
		public const float refreshConst = 5.0f;


		void Start(){
			InvokeRepeating("StateCompRefresh", 0, refreshConst);	
		
		}
		
		private void StateCompRefresh(){
			StartCoroutine(Main.Competition.GetCompetitionState());
			if(Main.Competition.state!="Not running"){
				SceneManager.LoadScene(3);
			}
		
		}



	}
}