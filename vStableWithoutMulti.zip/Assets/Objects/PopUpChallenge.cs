﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Serialization;
using UnityEngine.UI;

namespace Objects
{
    public class PopUpChallenge : MonoBehaviour
    {
        private GameObject player;
        public static Vector3 target; 
        public GameObject popUp;
        public Text popUpChallengeName;
        public Text popUpChallengeScore;
        public Text popUpChallengeDescription;
        public InputField popUpChallengeInputFlag;
        public Scene3 scene3;

        public void Start()
        {
            player = GameObject.Find("player");
            scene3 = FindObjectOfType<Scene3>();
        }

        public void AttachButton()
        {
            var challInfo = Main.Competition.challenges[int.Parse(Scene3._pcId)];
            if(String.Equals(challInfo.Category,"WEB"))
                Application.ExternalEval("window.open(\"" + challInfo.ChallLink + "\",\"_blank\")");
            else
                Application.ExternalEval("window.open('https://api.crisi5.com/api/challenges/"+ challInfo.Id+"/download','_self')");
        }
        
        public  void ClosePopUp()
        {
            popUpChallengeInputFlag.text = "";
            popUp.SetActive(false);
        }
        
        private void OnTriggerExit(Collider other)
        {
            if (other.CompareTag("Player"))
            {
                popUpChallengeInputFlag.text = "";
                popUp.SetActive(false);
            }
        }
        
        public void OnTriggerEnter(Collider other)
        {
            if (other.gameObject.CompareTag("Player"))
            {
                if (Vector3.Distance(player.transform.position, target) >= 5.5f) return;
                if (! Main.Team.challengesSolvedIndex.Contains(this.name))
                {
                    Scene3._pcId = this.name;
                    popUp.SetActive(true);
                    var challengeInfo = Main.Competition.challenges[int.Parse(Scene3._pcId)];
                    popUpChallengeName.text =challengeInfo.Name;
                    popUpChallengeScore.text = challengeInfo.Score;
                    popUpChallengeDescription.text = challengeInfo.Description;

                }
            }
        }

   
        
        
    }
    
}