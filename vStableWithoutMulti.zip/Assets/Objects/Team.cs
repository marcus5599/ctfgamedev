using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;

namespace Objects
{
	public class Team :MonoBehaviour{

		public string id;
		public new string name;
		public string score; 
		public string competitionId;
		public string color;
		public List<string> challengesSolvedIndex = new List<string>();
		public string rank;


		public void SetAttribute(JSONObject meAttribute){
			this.score = meAttribute["score"].n.ToString(CultureInfo.InvariantCulture);
			this.name = meAttribute["teamName"].str;
			this.color = meAttribute["team_color"].str;
			this.competitionId = meAttribute["competition_id"].str;
			this.rank = meAttribute["ranking"].n.ToString();
		}


	}
}