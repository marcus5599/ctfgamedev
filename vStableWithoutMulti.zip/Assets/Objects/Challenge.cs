using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Objects
{
	public class Challenge {
		public string Id;
		public string Name;
		public string Description;
		public string ChallLink;
		public string Category ;
		public string Score;
		public string Level;

		// Get Cha
		public static List<string> GetChallengesIndex(JSONObject challenges)
		{
			
			List<string> challengesId = new List<string>();
			List<string> challengesIndex = new List<string>();
			for (int i = 0; i < challenges.Count; i++)
			{
				challengesId.Add(challenges[i]["challenge_id"].str);
			}
			for(int i=0;i<Main.Competition.challenges.Count;i++)
			{
				if(challengesId.Contains(Main.Competition.challenges[i].Id))
				{
					challengesIndex.Add(i.ToString());
				}
			}

			return challengesIndex;
		}

		public void SetAttribute(JSONObject response){
			this.Id = response["id"].str;
			this.Name = response["challName"].str;
			this.Category = response["challCat"].str;
			this.Description = response["description"].str;
			this.ChallLink = response["challLink"].str;
			this.Score = response["challScore"].str;
			this.Level = response["challLevel"].str;
		}
		

	}
}