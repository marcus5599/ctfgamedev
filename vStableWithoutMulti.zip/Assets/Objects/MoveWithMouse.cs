﻿using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.AI;
using System.Collections;
using System.Collections.Generic;

namespace Objects
{
    public class MoveWithMouse : MonoBehaviour
    {
        private Camera camera;
        private Animator anim;
        private Vector3 prePosition_;
        private NavMeshAgent agent;
        // Use this for initialization
        void Start()
        {
            agent = GetComponent<NavMeshAgent>();
            camera = GameObject.Find("Main Camera").GetComponent<Camera>();
            prePosition_ = transform.position;
            anim = GetComponent<Animator>();
            //Application.ExternalCall("socket.emit", "playerconnect", FindObjectOfType<CTF>().user.nickname,FindObjectOfType<CTF>().team.teamName, FindObjectOfType<CTF>().team.team_color);
        }

        // Update is called once per frame
        [System.Obsolete]
        void Update()
        {
            if (Input.GetMouseButtonDown(0))
            {
                if (EventSystem.current.IsPointerOverGameObject())
                    return;


                Ray ray = camera.ScreenPointToRay(Input.mousePosition);
                RaycastHit hit;
                if (Physics.Raycast(ray, out hit))
                {
                    if (hit.transform.transform.name == "PlaneX")
                        return;
                    //Application.ExternalCall("socket.emit", "m", System.Math.Round(hit.point.x, 2), System.Math.Round(hit.point.z, 2));
                    PopUpChallenge.target = hit.point;
                    agent.SetDestination(hit.point);
                }
            }

            if (prePosition_ != transform.position)
            {
                anim.SetBool("Move", true);
                prePosition_ = transform.position;
            }
            else
            {
                anim.SetBool("Move", false);
            }

        }
    }
}