﻿using UnityEngine;

namespace Objects
{
    public class LookAtCamera : MonoBehaviour
    {
        private Camera camera;
        public GameObject AIX;
        public GameObject name;
        public GameObject team;
        private void Start()
        {
            camera = GameObject.Find("Main Camera").GetComponent<Camera>();
        }
        void Update()
        {
            Ray ray = camera.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit))
            {
                if (hit.collider.gameObject == AIX)
                {   
                    name.SetActive(true);
                    team.SetActive(true);
                    transform.LookAt(camera.transform);
                    transform.Rotate(0, 180, 0);
                }
                else
                {
                    if(name.activeSelf==true)
                    {
                        name.SetActive(false);
                        team.SetActive(false);
                    }

                }

            }
        }
    }
}
