using System.Collections;
using UnityEngine;
using UnityEngine.UI;

namespace Objects
{
	public class Scene4: MonoBehaviour {
		
		public GameObject scoreboard;
		public GameObject challengeSolved;
		public Text rank;
		public Text teamScore ;
		public Text playerTeam; 
		public Text  playerName;
		public Image challengeSolvedIcon;
		public Text challengeSolvedText;
		public GameObject contentOfLineScoreboard;
		public GameObject lineScoreboard;
		private Transform _lineRecent;
		private Text _rankTeams;
		private Text _scoreTeams;
		private Text _nameTeams;
		private Text _challengesSolvedTeams;
		

		public void Start()
		{
			CreateToolbox();
			playerName.text = Main.User.nickname;
			playerTeam.text = Main.Team.name;
			teamScore.text = Main.Team.score;
			rank.text = Main.Team.rank; // Get the Rank of the team 
			StartCoroutine(SolvedChallengeButton());
			StartCoroutine(ScoreboardButton());
		}
		void CreateToolbox()
		 
		{ 
			contentOfLineScoreboard.GetComponent<RectTransform>().sizeDelta = new Vector2(485,55*Main.Competition.teams.Count);  
			Vector3 pos = lineScoreboard.transform.position;
			for (var i = 1; i < Main.Competition.teams.Count; i++)
			{
				var line = CreateObject(lineScoreboard, "Line" + i.ToString(), pos);
				
				line.transform.SetParent(contentOfLineScoreboard.transform,false);

			}

			

		}
	
		public void OnSolvedChallengeClick()
		{
			Debug.Log("1");
			if (! scoreboard.activeSelf) Component.setPanel(scoreboard, challengeSolvedIcon, true);

			else
			{
				Component.setPanel(scoreboard, challengeSolvedIcon, false);

				
				
			}
		}

		public GameObject CreateObject(GameObject origin, string objectName, Vector3 objectPosition, GameObject parent = null)
		{
			var objectCreated = Instantiate(origin, objectPosition, origin.transform.rotation);
			objectCreated.name = objectName;
			if(parent)
			{
				if (parent != null)
				{
					objectCreated.transform.parent = parent.transform;
					objectCreated.transform.localPosition = objectPosition;
				}
				
			}

			return objectCreated;
		}
		public IEnumerator SolvedChallengeButton()
		{
			Request responseTeam = gameObject.AddComponent<Request>();
				yield return StartCoroutine(responseTeam.Get("me"));
				
				challengeSolvedText.text = "";
				for (var i = 0; i < responseTeam.data["solvedChallenges"].Count; i++)
				{
					challengeSolvedText.text += i + "-) "+ responseTeam.data["solvedChallenges"][i]["challenge"]["challName"].str + "\n";
				}
				
			
		}
		public IEnumerator ScoreboardButton()
		{
			Request responseTeam = gameObject.AddComponent<Request>();
				yield return StartCoroutine(responseTeam.Get("scoreboard"));
				for (var i = 0; i < Main.Competition.teams.Count; i++)
				{
					_lineRecent = contentOfLineScoreboard.transform.GetChild(i);
					_rankTeams  = _lineRecent.GetChild(0).GetChild(0).GetComponent<Text>();
					_scoreTeams = _lineRecent.GetChild(3).GetChild(1).GetComponent<Text>();
					_nameTeams  = _lineRecent.GetChild(1).GetChild(0).GetComponent<Text>();
					_challengesSolvedTeams =   _lineRecent.GetChild(2).GetChild(0).GetChild(1).GetComponent<Text>();
					_rankTeams.text = (i + 1).ToString();
					_scoreTeams.text = responseTeam.data[i]["score"].n.ToString();
					_nameTeams.text = responseTeam.data[i]["teamName"].str;
					_challengesSolvedTeams.text = "";
				
					for (var j = 0; j < responseTeam.data[i]["solvedChallenges"].Count; j++)
					{
						_challengesSolvedTeams.text += responseTeam.data[i]["solvedChallenges"][j]["challenge"]["challName"].str + "\n";
					}
					

				}
				
			
		}



		}



}