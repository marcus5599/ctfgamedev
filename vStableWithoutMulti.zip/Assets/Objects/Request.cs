using System.Collections;
using UnityEngine;
using UnityEngine.Networking;

namespace Objects
{
    public class Request : MonoBehaviour{
        public const string UrlApi = "https://api.crisi5.com/api/";
        public const string Port = "8080";
        public JSONObject data;

        //  Methods Get/POST/PUT
        public  IEnumerator Get(string endpoint){
            UnityWebRequest www = UnityWebRequest.Get(UrlApi+endpoint);
            www.SetRequestHeader("X-Requested-With", "XMLHttpRequest");
            yield return www.Send();
            if (www.isNetworkError || www.isHttpError)
            {
                Debug.Log(www.error);
                this.data = null;
             
            }
            else
            {
                this.data = new JSONObject(www.downloadHandler.text);

            }
        }
        
        public  IEnumerator Post(string endpoint,WWWForm form){
            UnityWebRequest www = UnityWebRequest.Post(UrlApi+endpoint, form);
            www.SetRequestHeader("X-Requested-With", "XMLHttpRequest");
            yield return www.Send();
            if (www.isNetworkError || www.isHttpError)
            {
                Debug.Log(www.error);
                this.data = null;
            }
            else
            {
                this.data = new JSONObject(www.downloadHandler.text);
            }
        }

        public  IEnumerator Put(string endpoint,WWWForm form){
       
            UnityWebRequest www = UnityWebRequest.Put(UrlApi+endpoint, form.data);
            www.SetRequestHeader("X-Requested-With", "XMLHttpRequest");
            yield return www.Send();
            if (www.isNetworkError || www.isHttpError)
            {
                Debug.Log(www.error);
                this.data = null;
            }
            else this.data = new JSONObject(www.downloadHandler.text);
        }

    }
}