﻿#region copyright
// --------------------------------------------------------------
//  Copyright (C) Dmitriy Yukhanov - focus [http://codestage.net]
// --------------------------------------------------------------
#endregion

namespace CodeStage.Maintainer.UI
{
	internal abstract class ReferencesChildTab : BaseTab
	{
		protected ReferencesChildTab(MaintainerWindow window) : base(window) {}
	}
}