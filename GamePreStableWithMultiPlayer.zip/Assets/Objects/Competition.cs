using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Serialization;

namespace Objects
{
    public class Competition : MonoBehaviour
    {
        public string id;
        public string time;
        public string endTime;
        public List<Challenge> challenges = new List<Challenge>() ;
        public Dictionary <string, List<int>> challengesByCat = new Dictionary<string, List<int>>() ; 
        public List<Team> teams = new List<Team>() ;
        public string state;
        public int nbrCategory = 0 ;
        public string timeRemain;


        private void SetAttribute(JSONObject response, JSONObject responseTeam)
        {
            this.id = response["competition"]["id"].str;
            this.state = response["competition"]["state"].str; //NOT RUNNING ON OVER
            this.time = response["competition"]["duration"].str;
            this.endTime = response["competition"]["will_end_at"].str;
            // Add Challenges to Competition //
            for (int i = 0; i < response["challenges"].Count; i++)
            {
                Challenge challenge = new Challenge();
                challenge.SetAttribute(response["challenges"][i]);
                Main.Competition.challenges.Add(challenge);
                if (this.challengesByCat.ContainsKey(challenge.Category))
                {
                    this.challengesByCat[challenge.Category]
                        .Add(i); // Divide challenges in Categories by the index in list Challenges
                }
                else
                {
                    this.challengesByCat.Add(challenge.Category, new List<int>() {i});
                    this.nbrCategory++;
                }
            }
            /////////////////////////////////

            // Add Teams to Competition //
            for (int i = 0; i < responseTeam.Count; i++)
            {
                Team team = gameObject.AddComponent<Team>();
                team.SetAttribute(responseTeam[i]);
                this.teams.Add(team);
            }
           
        }

        ///////////////
        public  IEnumerator GetCompetitionInfo(){
            Request responseTeam = gameObject.AddComponent<Request>();
            Request response = gameObject.AddComponent<Request>();
            yield return StartCoroutine(response.Get("challenges"));
            yield return StartCoroutine(responseTeam.Get("scoreboard"));
            if (response.data && responseTeam.data)
            {
                SetAttribute(response.data, responseTeam.data);
            }
            else Debug.Log("API Competition Failed");

        }
        public IEnumerator GetCompetitionState()
        {
            Request response = gameObject.AddComponent<Request>();
            yield return StartCoroutine(response.Get("competition/state"));
            if (response.data)
            {
                this.state = response.data["state"].str;
                // Verify if the Competition is on ///
                if (string.Equals(response.data["state"].str , "ON"))
                {
                    this.timeRemain = response.data["time_left"].str.Substring(11, 8);
                }
            }
            else
            {
                Debug.Log("Failed to get the State of Competition");
            }
        }
    }
}