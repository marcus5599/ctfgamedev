using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.AI;
// Scene for The Actual Game at the Competition Started or if The Competition is Over
namespace Objects
{
	public class Scene3: MonoBehaviour {
		public GameObject MiniCamera;
		private AudioSource Music;
		public Text playerName;
		public Text playerTeam; 
		public Text teamScore;
		public Text rank;
		public Text timeCounter;
		public GameObject pc0;
		public GameObject r0;
		private TextMesh _challengeText;
		public GameObject lineScoreboard;
		public GameObject contentOfLineScoreboard;
		public GameObject scoreboard;
		public Image scoreboardIcon;
		public GameObject challengeSolved;
		public Image challengeSolvedIcon;
		public GameObject settings;
		public Image settingsIcon;
		public Text challengeSolvedText;
		private Transform _lineRecent;
		private Text _rankTeams;
		private Text _scoreTeams;
		private Text _nameTeams;
		private Text _challengesSolvedTeams;
		public Material materialGreen ;
		public Material solved;
		private float limitWorld;
		public GameObject GameLimit;
		public NavMeshSurface surface;
		private int timeleft_h;
		private int timeleft_m;
		private int timeleft_s;
		public const int RefreshTime = 1 ;
		public const int RefreshScore = 30;
		public  static string _pcId;
		public  GameObject CorrectFlag;
		public  GameObject IncorrectFlag;
		public GameObject popUp;
		public Text popUpChallengeInputFlag;
		public GameObject sideLimit;
		public Material sideZone;
		public GameObject characterman;
		public GameObject characterwoman;
		public GameObject camera;
		public GameObject minimapCamera;

		void Start()
		{
			timeleft_h = int.Parse(Main.Competition.timeRemain.Substring(0, 2));
			timeleft_m = int.Parse(Main.Competition.timeRemain.Substring(3, 2));
			timeleft_s = int.Parse(Main.Competition.timeRemain.Substring(6, 2));
			setcharacter();
			CreateWorld();
			InvokeRepeating("Timer", 1, RefreshTime);	
			InvokeRepeating("refreshScoreUp", 30, RefreshScore);	
			
		}
		public void setcharacter()
		{
			if (Main.isman== 1) CreateObject(characterman,"player",characterman.transform.position);
			else CreateObject(characterwoman,"player",characterman.transform.position);
			camera.GetComponent<CameraFollow>().enabled = true;
			minimapCamera.GetComponent<MinimapFollow>().enabled = true;
			Music = GameObject.Find("player").GetComponent<AudioSource>();

		}
			public void refreshScoreUp(){
			StartCoroutine(refreshScore());
		}

		public IEnumerator refreshScore()
		{
			yield return Main.User.Me();
			rank.text = Main.Team.rank;
			teamScore.text = Main.Team.score;
			if (scoreboard.activeSelf)
			{
				
				StartCoroutine(ScoreboardButton());
			}
			if (challengeSolved.activeSelf == true) StartCoroutine(SolvedChallengeButton());
		}
		void CreateWorld(){
			CreateHeader();
			StartCoroutine(CreateRooms(Main.Competition.challengesByCat));
			CreateToolbox();
			Music.Play();

		}

		public void Timer()
		{
			if (timeleft_m == 0 && timeleft_h == 0 && timeleft_s == 0)
			{
				SceneManager.LoadScene(5);
				return ;
			}
			if (timeleft_s > 0) timeleft_s--;
			else
			{
				timeleft_s = 59;	
				if (timeleft_m > 0) timeleft_m--;
				else
				{
					timeleft_m = 59;
					timeleft_h --;
				}
				
			}

			timeCounter.text = timeleft_h.ToString() + ":" + timeleft_m.ToString() + ":" + timeleft_s.ToString();
		}



		public void OnSettingButtonClick()
		{
			if (settings.activeSelf) Component.setPanel(settings, settingsIcon, false);
			else
			{
				Component.setPanel(settings, settingsIcon, true);
				Component.setPanel(scoreboard, scoreboardIcon, false);
				Component.setPanel(challengeSolved, challengeSolvedIcon, false);
			}
		}
		public void OnSolvedChallengeClick()
		{
			if (challengeSolved.activeSelf) Component.setPanel(challengeSolved, challengeSolvedIcon, false);
			else
			{
				Component.setPanel(challengeSolved, challengeSolvedIcon, true);
				Component.setPanel(settings, settingsIcon, false);
				Component.setPanel(scoreboard, scoreboardIcon, false);
				StartCoroutine(SolvedChallengeButton());
			}
		}
		public void OnScoreboardClick()
		{
			if (scoreboard.activeSelf) Component.setPanel(scoreboard, scoreboardIcon, false);
			else
			{
				Component.setPanel(challengeSolved, challengeSolvedIcon, false);
				Component.setPanel(settings, settingsIcon, false);
				Component.setPanel(scoreboard, scoreboardIcon, true);
				StartCoroutine(ScoreboardButton());
			}

			
		}
		public IEnumerator SolvedChallengeButton()
		{
			Request responseTeam = gameObject.AddComponent<Request>();
				yield return StartCoroutine(responseTeam.Get("me"));
				
				challengeSolvedText.text = "";
				for (var i = 0; i < responseTeam.data["solvedChallenges"].Count; i++)
				{
					challengeSolvedText.text += i + "-) "+ responseTeam.data["solvedChallenges"][i]["challenge"]["challName"].str + "\n";
				}
				
			
		}
		public IEnumerator ScoreboardButton()
		{
			Request responseTeam = gameObject.AddComponent<Request>();
				yield return StartCoroutine(responseTeam.Get("scoreboard"));
				for (var i = 0; i < Main.Competition.teams.Count; i++)
				{
					_lineRecent = contentOfLineScoreboard.transform.GetChild(i);
					_rankTeams  = _lineRecent.GetChild(0).GetChild(0).GetComponent<Text>();
					_scoreTeams = _lineRecent.GetChild(3).GetChild(1).GetComponent<Text>();
					_nameTeams  = _lineRecent.GetChild(1).GetChild(0).GetComponent<Text>();
					_challengesSolvedTeams =   _lineRecent.GetChild(2).GetChild(0).GetChild(1).GetComponent<Text>();
					_lineRecent.GetChild(2).GetChild(0).GetChild(1).GetComponent<RectTransform>().sizeDelta = new Vector2(12.64f,15*responseTeam.data[i]["solvedChallenges"].Count);
					_rankTeams.text = (i + 1).ToString();
					_scoreTeams.text = responseTeam.data[i]["score"].n.ToString();
					_nameTeams.text = responseTeam.data[i]["teamName"].str;
					_challengesSolvedTeams.text = "";
					for (var j = 0; j < responseTeam.data[i]["solvedChallenges"].Count; j++)
					{
						_challengesSolvedTeams.text += responseTeam.data[i]["solvedChallenges"][j]["challenge"]["challName"].str + "\n";
					}
					

				}
				
			
		}

		void CreateToolbox()
		 
		{ 
			contentOfLineScoreboard.GetComponent<RectTransform>().sizeDelta = new Vector2(485,55*Main.Competition.teams.Count);  
			Vector3 pos = lineScoreboard.transform.position;
			for (var i = 1; i < Main.Competition.teams.Count; i++)
			{
				var line = CreateObject(lineScoreboard, "Line" + i.ToString(), pos);
				
				line.transform.SetParent(contentOfLineScoreboard.transform,false);

			}

			Component.setPanel(scoreboard, scoreboardIcon, false);

		}
		void CreateHeader(){
			playerName.text = Main.User.nickname;
			playerTeam.text = Main.Team.name;
			teamScore.text = Main.Team.score;
			rank.text = Main.Team.rank;  // Get the Rank of the team 
			timeCounter.text = Main.Competition.timeRemain;
		}
		IEnumerator CreateRooms(Dictionary <string, List<int>> challengesByCat){
		
			var room = r0.transform.GetChild(0); // Get The Children room of ROOM R0 
			var arrow = room.transform.GetChild(0); // Get the Children arrow of room
			var categoryText = arrow.transform.GetChild(0).GetComponent<TextMesh>(); // Get the Text of The arrow
			var challengeName = pc0.transform.GetChild(0);
			_challengeText = challengeName.transform.GetChild(2).GetComponent<TextMesh>();
			int counter = 0;
			foreach(KeyValuePair<string, List<int>> entry in challengesByCat)
			{
				CreateRoom(counter,entry.Value,categoryText,entry.Key);
				counter++;
			}
			counter--;
			foreach (var t in Main.Team.challengesSolvedIndex)
			{
				ClosePC(GameObject.Find(t));
				
			}

			limitWorld = (counter / 2 +1)* 20-90 ;
			yield return GameLimit.transform.position =new Vector3(0,4,limitWorld+8);
			sideLimit.transform.position = new Vector3(sideLimit.transform.position.x, sideLimit.transform.position.y, (-89.73f + limitWorld) / 2);
			sideLimit.transform.localScale = new Vector3(Mathf.Abs(-89.73f-limitWorld)+0.2f,22.8f,0.2f);
			Instantiate(sideLimit, new Vector3(sideLimit.transform.position.x*(-1), sideLimit.transform.position.y, sideLimit.transform.position.z),sideLimit.transform.rotation);
			sideZone.mainTextureScale = new Vector2 (sideLimit.transform.localScale.x / 10, sideLimit.transform.localScale.y / 10);
			surface.BuildNavMesh();
			
		}
		void CreateRoom(int nRoom , List<int> challengesId,TextMesh categoryText,string nameCategory)
		{
			categoryText.text = nameCategory; // Get the Name of Category and Set it to arrow 
			float z = (nRoom/2) * 20 - 80;
			float x = 30 * Mathf.Pow(-1, nRoom);
			var room = CreateObject(r0, "ROOM" + nRoom.ToString(), new Vector3(x, 0, z));
			for(int i = 0 ; i<challengesId.Count;i++)
			{
				CreatePc(challengesId[i], room, i, nRoom);
			}
			if(nRoom%2!=0) room.transform.Rotate(0, 180, 0);
		}

		void CreatePc(int idChallenge , GameObject room, int nPc,int nRoom )
		{
			
			_challengeText.text = Main.Competition.challenges[idChallenge].Name; // Get the Challenge name and affect it to arrow of PC 
			float z = (nPc % 2) * 11 - 6.25f;
			float x = 9*(nPc/2)  - 17;
			var PC = CreateObject(pc0, idChallenge.ToString(), new Vector3(x, 0.15f, z),room);
			PC.SetActive(true);
		}

		public void ClosePC(GameObject PC)
		{
			PC.transform.GetChild(0).transform.GetChild(0).GetComponent<Renderer>().sharedMaterial = materialGreen;
			PC.transform.GetChild(0).transform.GetChild(1).GetComponent<Renderer>().sharedMaterial = materialGreen;
			PC.transform.GetChild(1).GetComponent<Renderer>().sharedMaterial = solved;
			
		}

		public GameObject CreateObject(GameObject origin, string objectName, Vector3 objectPosition, GameObject parent = null)
		{
			var objectCreated = Instantiate(origin, objectPosition, origin.transform.rotation);
			objectCreated.name = objectName;
			if(parent)
			{
				if (parent != null)
				{
					objectCreated.transform.parent = parent.transform;
					objectCreated.transform.localPosition = objectPosition;
				}
				
			}

			return objectCreated;
		}
		
		public IEnumerator submit()
		{
			WWWForm form = new WWWForm();
			form.AddField("flag",popUpChallengeInputFlag.text);
			Request response = gameObject.AddComponent<Request>();
			yield return StartCoroutine(response.Post("challenges/" + Main.Competition.challenges[int.Parse(Scene3._pcId)].Id + "/flag",form));
			popUpChallengeInputFlag.text = "";
			if (response.data)
			{
				if (!response.data["success"].b)
				{
					IncorrectFlag.SetActive(true);
					yield return new WaitForSeconds(1.3f);
					IncorrectFlag.SetActive(false);
				}
				else
				{
					popUpChallengeInputFlag.text = "";
					popUp.SetActive(false);
					CorrectFlag.SetActive(true);
					ClosePC(GameObject.Find(_pcId));
					StartCoroutine(refreshScore());
					yield return new WaitForSeconds(1.1f);
					CorrectFlag.SetActive(false);
                    
				}
			}
			else
			{
				IncorrectFlag.SetActive(true);
				IncorrectFlag.transform.GetChild(0).GetComponent<Text>().text = "Already Solved ! ";
				popUpChallengeInputFlag.text = "";
				popUp.SetActive(false);
				yield return  new WaitForSeconds(1);
				IncorrectFlag.transform.GetChild(0).GetComponent<Text>().text = "Incorrect Flag ! ";
				IncorrectFlag.SetActive(false);
			}
            
		}
		public void onClickSubmit()
		{
			StartCoroutine(submit());
		}

		public void MapUpdate(bool MiniCameraState)
    	{
        	MiniCamera.SetActive(MiniCameraState);
    	}
    	public void MusicUpdate(float MusicState)
        {
	        Music.volume = MusicState; 
        }

	}
}
