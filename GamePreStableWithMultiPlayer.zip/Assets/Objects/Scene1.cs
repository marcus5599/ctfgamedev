using System.Collections;
using UnityEngine;
using UnityEngine.UI;

// Scene for Sign In and Reading Rules 
namespace Objects
{
	public class Scene1: MonoBehaviour {

		public InputField usernameInput;
		public InputField passwordInput;
		public Text resultMsg;
		public GameObject rules;
		public GameObject login;
		public Main main;

		void Start(){
			main = FindObjectOfType(typeof(Main)) as Main;
			usernameInput.Select();
			usernameInput.ActivateInputField();
		}

		private void Update(){
			if (Input.GetKeyDown(KeyCode.Tab)){
				if (usernameInput.isFocused){
					passwordInput.Select();
					passwordInput.ActivateInputField();
				}
				else{
					if (passwordInput.isFocused){
						usernameInput.Select();
						usernameInput.ActivateInputField();
					}
				} 
			} 
			if (Input.GetKeyDown(KeyCode.Return)) StartCoroutine(LoginButton());
		}

		public IEnumerator LoginButton()
		{
			yield return StartCoroutine(Main.User.Login(usernameInput.text,passwordInput.text));
			// User enter a correct User and Password
			if(Main.User.loginResponse)
			{
				resultMsg.text = "Access granted";
				resultMsg.color = Color.green;
				yield return new WaitForSeconds(0.35f);
				Application.ExternalEval("localStorage.setItem('io_token',"+Main.User.loginResponse["io_token"]+")");
				if((int)Main.User.loginResponse["rules_seen"].n==1) StartCoroutine(main.StartGame());
				else
				{
					if (rules != null) rules.SetActive(true);
					if (login != null) login.SetActive(false);
				}
			}
			// User Enter a Username/Password Incorrect
			if(!Main.User.loginResponse)
			{
				resultMsg.color = Color.red;
				resultMsg.text = "Access denied";
				passwordInput.text = "";
				passwordInput.Select();
				passwordInput.ActivateInputField();
				yield return new WaitForSeconds(2.2f);
				resultMsg.text = "";
			}
        
		}
		public void OnClickLogin()
		{
			StartCoroutine(LoginButton());
		}
		// Triggered  When the User Click on I read rules 
		public IEnumerator RulesRead(){
			WWWForm form = new WWWForm();
			form.AddField("rules_seen", "1");
			Request response = gameObject.AddComponent<Request>();
			yield return StartCoroutine(response.Put("accept",form));
			if(response.data) yield return StartCoroutine(main.StartGame());
			else Debug.Log("API Reading rules Fails");

		}
		public void OnClickRules()
		{
			StartCoroutine(RulesRead());
		}
	}
}