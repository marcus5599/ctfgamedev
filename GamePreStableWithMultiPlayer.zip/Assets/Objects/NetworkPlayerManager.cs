﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Objects
{
    public class NetworkPlayerManager : MonoBehaviour
    {
        public GameObject malePrefab;
        public GameObject femalePrefab;
        public Material minimapcolor; 
        private Dictionary<string, NetworkPlayerController> players = new Dictionary<string, NetworkPlayerController>();
        public GameObject blurPopUp;
        void Awake()
        {
            Application.ExternalCall("connectToSocket");

        }

        private void Start()
        {
            //StartCoroutine(unitTest());
        }

        public void playerConnect(string data)
        {
            var args = data.Split(';');
            GameObject player;
            if (args[3] == "1")
                player = Instantiate(malePrefab, new Vector3(float.Parse(args[4]), 0.1f, float.Parse(args[5])),
                    Quaternion.identity) as GameObject;
            else
                player = Instantiate(femalePrefab, new Vector3(float.Parse(args[4]), 0.1f, float.Parse(args[5])),
                    Quaternion.identity) as GameObject;
            player.name = args[0];
            var UI = player.transform.GetChild(0);
            UI.transform.GetChild(0).GetComponent<TextMesh>().text = args[0];
            var teamName = UI.transform.GetChild(1).GetComponent<TextMesh>();
            teamName.text = args[1];
            teamName.color = Component.ToColor(args[2]);
            if (string.Compare(args[1], Main.Team.name) == 0) minimapcolor.SetColor("_BaseColor", teamName.color);
            var otherPlayer = player.GetComponent<NetworkPlayerController>();
            players.Add(args[0], otherPlayer);

        }
        void M(string data)
        {
            var args = data.Split(';');
            if(players.ContainsKey(args[0]))
                players[args[0]].move(float.Parse(args[1]), float.Parse(args[2]));
        }
        void destoryPlayer(string name)
        {
            if (players.ContainsKey(name))
            {
                Destroy(players[name].gameObject);
                players.Remove(name);
            }
            

        }

        void PopUpError(string id)
        {
            var textError = "";
            switch (id)
            {
                case "1":
                    textError = "Un-Autorized Client!";
                    break;
                case "2":
                    textError = "You are already Connected!";
                    break;
                case "3":
                    textError = "Connexion Error ...";
                    ;
                    break;
                case "4":
                    textError = "Something Went Wrong ...";
                    break;
                default:
                    textError = "Something Went Wrong ... - Incorrect ID ";
                    break;
            }
            blurPopUp.transform.GetChild(2).GetComponent<Text>().text = textError;
            blurPopUp.SetActive(true);
        }

        public void refreshButton()
        {
            Application.ExternalCall("location.reload()");
        }
        public IEnumerator unitTest()
        {
            playerConnect("karima;teamDyalKarima;#fff833;2;0;-70");
            yield return new WaitForSeconds(7);
            M("karima;10;-80");
            yield return new WaitForSeconds(5);
            destoryPlayer("karima");
            yield return new WaitForSeconds(5);
            PopUpError("2");
            
        }
    }
}