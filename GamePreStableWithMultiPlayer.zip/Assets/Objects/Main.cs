﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Objects
{
    public class Main : MonoBehaviour
    {

        public static User User;
        public static Team Team;
        public static Competition Competition;
        public static int isman= 0;
        // Start is called before the first frame update
        void Start()
        {
            User = gameObject.GetComponent<User>();
            Team = gameObject.GetComponent<Team>();
            Competition = gameObject.GetComponent<Competition>();
            StartCoroutine(StartGame());

        }

        public void getPlayerGender(int gender) // Get The Gender of Player From LocalStorage
        {
            isman = gender;
        }
        //The Start of The game 
        public IEnumerator  StartGame()
        {
            yield return StartCoroutine(User.IsConnected());
            // User Already Connected but just refresh the Nav 
            if (User.connectedResponse)
            {
                Application.ExternalCall("getPlayerGender");
                yield return StartCoroutine(Competition.GetCompetitionInfo());
                //Debug.Log(Competition.challenges[0]);
                yield return StartCoroutine(User.Me());
                yield return StartCoroutine(Competition.GetCompetitionState());
                // If the Competition is Not Running .. 
                if (String.Equals(Competition.state, "Not running")) SceneManager.LoadScene(2);
                // IF the Competition is Over 
                else if (String.Equals(Competition.state, "OVER")) SceneManager.LoadScene(5);
                // IF the Competition is ON and Running 
                else if(isman==0)  SceneManager.LoadScene(3);
                else if (String.Equals(Competition.state, "ON")) SceneManager.LoadScene(4);

            }
            //// For the first Time ///////
            else SceneManager.LoadScene(1);
        
        }
        
        
    
    }
}