﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class CameraFollow : MonoBehaviour
{
    private static GameObject TargetToFollow;
    public float Cameralimit;
    public bool RotateAroundPlayer = true;
    public float RotationSpeed = 5.0f;
    private Vector3 _cameraOffset;
    public float SmoothFactor = 1f;
    private void Start()
    {
        TargetToFollow = GameObject.Find("player");
        _cameraOffset = transform.position - TargetToFollow.transform.position;
    }
    // Update is called once per frame
    void LateUpdate()
    {
        
        if(RotateAroundPlayer && Input.GetMouseButton(1))
        {
            Quaternion camturnAngle = Quaternion.AngleAxis(Input.GetAxis("Mouse X") * RotationSpeed, Vector3.up);
            _cameraOffset = camturnAngle * _cameraOffset;

        }
        Vector3 newPos = TargetToFollow.transform.position + _cameraOffset;

        transform.position = Vector3.Slerp(transform.position, newPos, SmoothFactor);

        if (RotateAroundPlayer) {
            transform.LookAt(TargetToFollow.transform);
        }
        if (EventSystem.current.IsPointerOverGameObject())
            return;
        if (Input.GetAxis("Mouse ScrollWheel")>0)
        {
            if (GetComponent<Camera>().fieldOfView>40) 
            GetComponent<Camera>().fieldOfView-=2;
        }
        if (Input.GetAxis("Mouse ScrollWheel") < 0)
        {
            if (GetComponent<Camera>().fieldOfView < 70)
                GetComponent<Camera>().fieldOfView+=2;
        }
       
    }   
}
