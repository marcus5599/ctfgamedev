using System.Collections;
using System.Globalization;
using UnityEngine;

namespace Objects
{
    public class User : MonoBehaviour{

        public string id;
        public string nickname;
        public string score;
        public string idTeam;
        public bool rulesSeen;
        public JSONObject connectedResponse;
        public JSONObject loginResponse;
        void  SetAttribute(JSONObject meAttribute){
            this.id = meAttribute["profile"]["id"].str;
            this.nickname = meAttribute["profile"]["nickname"].str;
            this.score = meAttribute["profile"]["score"].n.ToString(CultureInfo.InvariantCulture);
        }
        // Me Function 
        public IEnumerator Me()
        {
            Request response = gameObject.AddComponent<Request>();
            yield return StartCoroutine(response.Get("me"));
            if (response.data)
            {
                this.SetAttribute(response.data);
                Main.Team.SetAttribute(response.data["team"]);
                Main.Team.challengesSolvedIndex = Challenge.GetChallengesIndex(response.data["solvedChallenges"]);
                
            }
            else
            {
                Debug.Log("API me Failed");
            }
        }

        // Login Function 
        public  IEnumerator Login(string username, string password)
        {
            WWWForm form = new WWWForm();
            form.AddField("nickname", username);
            form.AddField("password", password);
            form.AddField("fingerprint", "aaaa");
            Request responseLogin = gameObject.AddComponent<Request>();
            yield return StartCoroutine(responseLogin.Post("login", form));
            this.loginResponse = responseLogin.data;
        }
        // Is User Authenticated
        public IEnumerator IsConnected()
        {
            WWWForm form = new WWWForm();
            form.AddField("_cssv", "aaaa");
            Request response = gameObject.AddComponent<Request>();
            yield return StartCoroutine(response.Post("auth", form));
            this.connectedResponse =  response.data;
        }
               
    }
}
    



