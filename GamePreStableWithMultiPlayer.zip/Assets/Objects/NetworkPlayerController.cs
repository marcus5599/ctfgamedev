﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

namespace Objects
{
    public class NetworkPlayerController : MonoBehaviour
    {
        private Vector3 prePosition  = Vector3.zero;
        public Animator anim;

        public NavMeshAgent agent;

        public void move(float x, float z)
        {
            agent.SetDestination(new Vector3(x, 0, z));
        }
        

        public void Update()
        {
            if (prePosition != transform.position)
            {
                anim.SetBool("Move", true);
                prePosition = transform.position;
            }
            else
            {
                anim.SetBool("Move", false);
            }
        }
    }
    
}

