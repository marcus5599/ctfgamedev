﻿using System.Collections;
using System.Collections.Generic;
using Objects;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
public class choosingPlayer : MonoBehaviour
{
    public GameObject man;
    public GameObject woman;
    public void ManUpdate(bool charachter_man)
    {
        man.SetActive(charachter_man);
        
        //woman.SetActive(!charachter_man);
    }
    public void WomanUpdate(bool charachter_Woman)
    {
        //man.SetActive(!charachter_Woman);
        woman.SetActive(charachter_Woman);
    }
    public void okButton()
    {
        if (man.activeSelf) Main.isman = 1;
        else Main.isman = 2;
        Application.ExternalCall("savePlayerGender",Main.isman);
        
        SceneManager.LoadScene(4);
    }
} 
